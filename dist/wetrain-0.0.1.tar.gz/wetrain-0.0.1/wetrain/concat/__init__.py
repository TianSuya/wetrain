import os,sys

path = os.path.dirname(__file__)
sys.path.append(path)

from .concat import Concat