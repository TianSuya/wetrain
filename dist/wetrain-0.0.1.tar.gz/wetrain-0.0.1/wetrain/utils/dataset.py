class Dataset(object):

    def __init__(self):
        pass

    def __getitem__(self, idx):
        pass

    def __len__(self):
        pass