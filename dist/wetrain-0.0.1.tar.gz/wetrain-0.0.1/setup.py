import setuptools

setuptools.setup(
    name='wetrain',
    version='0.0.1',
    author='tbw',
    author_email='t18637403315@163.com',
    description='a simple deep learning framework',
    packages=setuptools.find_packages()
)