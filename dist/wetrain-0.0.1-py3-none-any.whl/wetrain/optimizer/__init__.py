import os,sys

path = os.path.dirname(__file__)
sys.path.append(path)

from sgd_opt import SgdOptimizer