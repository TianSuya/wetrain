
class base_model:

    def __init__(self):
        pass

    def in_concat(self):
        pass

    def out_concat(self):
        pass